package com.example.asach;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    RadioButton r;
    ToggleButton t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        Button btn = findViewById(R.id.button);
        RadioGroup g = findViewById(R.id.radioGroup);
        t1 = findViewById(R.id.toggleButton);
        t2 = findViewById(R.id.toggleButton2);

        TextView textView = findViewById(R.id.textView);
        EditText textView2 = findViewById(R.id.editTextNumber);
        EditText textView3 = findViewById(R.id.editTextNumber2);

        Button btn2 = findViewById(R.id.button2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1 = Integer.parseInt(textView2.getText().toString());
                int n2 = Integer.parseInt(textView3.getText().toString());

                Toast.makeText(MainActivity.this, "Addition="+(n1+n2), Toast.LENGTH_SHORT).show();
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int no = g.getCheckedRadioButtonId();
                r = findViewById(no);
                Toast.makeText(MainActivity.this," "+ r.getText(), Toast.LENGTH_SHORT).show();

                String ans1 = t1.getText().toString();
                String ans2 = t2.getText().toString();
                String finalans = "In First="+ans1+" in second="+ans2;
                textView.setText(finalans);

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int no = item.getItemId();

        if (no == R.id.go)
        {
            Toast.makeText(this, "go go power ranger", Toast.LENGTH_SHORT).show();
        }
        if (no == R.id.jo)
        {
            Toast.makeText(this, "go go power jj", Toast.LENGTH_SHORT).show();
        }
        if (no == R.id.kk)
        {
            Toast.makeText(this, "go go power kk", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        menuInflater.inflate(R.menu.toolbar_menu,menu);
        return true;

    }
}